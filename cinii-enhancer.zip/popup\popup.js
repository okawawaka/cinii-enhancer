/**
 * CiNii Research Enhancer - Popup Controller
 */

const DEFAULT_SETTINGS = {
  enableSearchQuickCopy: true,
  enableDetailToolbar: true,
  enableAbstractCleanup: true,
  preferredCitation: 'bibtex',
  customTemplate: '{authors} ({year})「{title}」『{journal}』{volume}({issue}), pp.{pages}. {url}',
  customTemplateArticle: '{authors} ({year})「{title}」『{journal}』{volume}({issue}), pp.{pages}. {url}',
  customTemplateBook: '{authors} ({year})『{title}』{place}: {publisher}. {url}',
  customTemplateDissertation: '{authors} ({year})『{title}』博士論文, {publisher}. {url}',
  customTemplateLabel: 'カスタム',
  enableItemTypeTemplate: true
};

document.addEventListener('DOMContentLoaded', async () => {
  const storage = chrome.storage.sync || chrome.storage.local;

  const enableDetailToolbarInput = document.getElementById('enableDetailToolbar');
  const enableSearchQuickCopyInput = document.getElementById('enableSearchQuickCopy');
  const enableAbstractCleanupInput = document.getElementById('enableAbstractCleanup');
  const preferredCitationInput = document.getElementById('preferredCitation');
  const saveBtn = document.getElementById('saveBtn');
  const saveStatus = document.getElementById('saveStatus');

  const badgeDetailToolbar = document.getElementById('badge-detail-toolbar');
  const badgeSearchCopy = document.getElementById('badge-search-copy');
  const badgeAbstractCleanup = document.getElementById('badge-abstract-cleanup');

  let statusTimeout = null;
  const showStatus = (text, isError = false) => {
    if (!saveStatus) return;
    saveStatus.textContent = text;
    saveStatus.className = 'save-status is-visible' + (isError ? ' error' : '');
    if (statusTimeout) clearTimeout(statusTimeout);
    statusTimeout = setTimeout(() => {
      saveStatus.classList.remove('is-visible');
    }, 1800);
  };

  const updateBadge = (checkbox, badge) => {
    if (!checkbox || !badge) return;
    if (checkbox.checked) {
      badge.textContent = '有効';
      badge.className = 'status-badge badge-on';
    } else {
      badge.textContent = '無効';
      badge.className = 'status-badge badge-off';
    }
  };

  let loadedSettings = { ...DEFAULT_SETTINGS };

  const saveCurrentSettings = async (showFeedback = true) => {
    const newSettings = {
      ...loadedSettings,
      enableDetailToolbar: Boolean(enableDetailToolbarInput?.checked),
      enableSearchQuickCopy: Boolean(enableSearchQuickCopyInput?.checked),
      enableAbstractCleanup: Boolean(enableAbstractCleanupInput?.checked),
      preferredCitation: preferredCitationInput?.value || 'bibtex'
    };

    try {
      await storage.set(newSettings);
      loadedSettings = newSettings;
      if (showFeedback) showStatus('設定を保存しました');
    } catch (err) {
      console.error('Failed to save settings:', err);
      if (showFeedback) showStatus('保存エラー', true);
    }
  };

  // Wire badge update and auto-save events
  if (enableDetailToolbarInput && badgeDetailToolbar) {
    enableDetailToolbarInput.addEventListener('change', () => {
      updateBadge(enableDetailToolbarInput, badgeDetailToolbar);
      saveCurrentSettings(true);
    });
  }
  if (enableSearchQuickCopyInput && badgeSearchCopy) {
    enableSearchQuickCopyInput.addEventListener('change', () => {
      updateBadge(enableSearchQuickCopyInput, badgeSearchCopy);
      saveCurrentSettings(true);
    });
  }
  if (enableAbstractCleanupInput && badgeAbstractCleanup) {
    enableAbstractCleanupInput.addEventListener('change', () => {
      updateBadge(enableAbstractCleanupInput, badgeAbstractCleanup);
      saveCurrentSettings(true);
    });
  }
  if (preferredCitationInput) {
    preferredCitationInput.addEventListener('change', () => {
      saveCurrentSettings(true);
    });
  }

  // Load current settings
  try {
    const current = await storage.get(DEFAULT_SETTINGS);
    loadedSettings = { ...DEFAULT_SETTINGS, ...current };

    if (enableDetailToolbarInput) enableDetailToolbarInput.checked = Boolean(loadedSettings.enableDetailToolbar);
    if (enableSearchQuickCopyInput) enableSearchQuickCopyInput.checked = Boolean(loadedSettings.enableSearchQuickCopy);
    if (enableAbstractCleanupInput) enableAbstractCleanupInput.checked = Boolean(loadedSettings.enableAbstractCleanup);

    if (preferredCitationInput && loadedSettings.preferredCitation) {
      preferredCitationInput.value = loadedSettings.preferredCitation;
    }

    updateBadge(enableDetailToolbarInput, badgeDetailToolbar);
    updateBadge(enableSearchQuickCopyInput, badgeSearchCopy);
    updateBadge(enableAbstractCleanupInput, badgeAbstractCleanup);
  } catch (err) {
    console.error('Failed to load settings:', err);
  }

  // Explicit save on button click
  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      saveCurrentSettings(true);
    });
  }
});
